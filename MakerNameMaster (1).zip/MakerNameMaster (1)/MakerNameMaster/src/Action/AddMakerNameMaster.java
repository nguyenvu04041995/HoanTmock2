package Action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import Form.MakerNameMasterForm;

import model.Bo.MakerNameMasterBo;

public class AddMakerNameMaster extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		MakerNameMasterForm makerNameMasterForm = (MakerNameMasterForm) form;

		if ("更新(U)".equals(makerNameMasterForm.getSubmit())) { 
			String[] manufactureCode = makerNameMasterForm.getManufactureCode();
			String[] manufactureName = makerNameMasterForm.getManufactureName();
            
			MakerNameMasterBo makerNameMasterBo = new MakerNameMasterBo();
			for (int i = 0; i < 10; i++) {
			makerNameMasterBo.AddMakerNameMaster(manufactureCode[i], manufactureName[i]);
			}
			return mapping.findForward("AddMakerNameMasterxong");
		} else { // chuyen sang trang Them sinh vien
			return mapping.findForward("AddMakerNameMaster");
		}
	}

}
