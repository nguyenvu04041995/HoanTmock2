package Form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.Bean.MakerNameMaster;

public class DanhSachMakerNameMasterForm extends ActionForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String submitUpdate;
	private String[] updateChar;
	private String[] manufactureName;
	private String manufactureCode;
	private String[] manufactureCode1;
	private ArrayList<MakerNameMaster> listMakerNameMaster;
	/**
	 * @return the submitUpdate
	 */
	public String getSubmitUpdate() {
		return submitUpdate;
	}
	/**
	 * @param submitUpdate the submitUpdate to set
	 */
	public void setSubmitUpdate(String submitUpdate) {
		this.submitUpdate = submitUpdate;
	}
	/**
	 * @return the updateChar
	 */
	public String[] getUpdateChar() {
		return updateChar;
	}
	/**
	 * @param updateChar the updateChar to set
	 */
	public void setUpdateChar(String[] updateChar) {
		this.updateChar = updateChar;
	}
	/**
	 * @return the manufactureName
	 */
	public String[] getManufactureName() {
		return manufactureName;
	}
	/**
	 * @param manufactureName the manufactureName to set
	 */
	public void setManufactureName(String[] manufactureName) {
		this.manufactureName = manufactureName;
	}
	/**
	 * @return the manufactureCode
	 */
	public String getManufactureCode() {
		return manufactureCode;
	}
	/**
	 * @param manufactureCode the manufactureCode to set
	 */
	public void setManufactureCode(String manufactureCode) {
		this.manufactureCode = manufactureCode;
	}
	/**
	 * @return the manufactureCode1
	 */
	public String[] getManufactureCode1() {
		return manufactureCode1;
	}
	/**
	 * @param manufactureCode1 the manufactureCode1 to set
	 */
	public void setManufactureCode1(String[] manufactureCode1) {
		this.manufactureCode1 = manufactureCode1;
	}
	/**
	 * @return the listMakerNameMaster
	 */
	public ArrayList<MakerNameMaster> getListMakerNameMaster() {
		return listMakerNameMaster;
	}
	/**
	 * @param listMakerNameMaster the listMakerNameMaster to set
	 */
	public void setListMakerNameMaster(ArrayList<MakerNameMaster> listMakerNameMaster) {
		this.listMakerNameMaster = listMakerNameMaster;
	}
	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	/**
	 * @param submitUpdate
	 * @param updateChar
	 * @param manufactureName
	 * @param manufactureCode
	 * @param manufactureCode1
	 * @param listMakerNameMaster
	 */
	public DanhSachMakerNameMasterForm(String submitUpdate, String[] updateChar, String[] manufactureName,
			String manufactureCode, String[] manufactureCode1, ArrayList<MakerNameMaster> listMakerNameMaster) {
		super();
		this.submitUpdate = submitUpdate;
		this.updateChar = updateChar;
		this.manufactureName = manufactureName;
		this.manufactureCode = manufactureCode;
		this.manufactureCode1 = manufactureCode1;
		this.listMakerNameMaster = listMakerNameMaster;
	}
	/**
	 * 
	 */
	public DanhSachMakerNameMasterForm() {
		super();
	}
	
	
}
