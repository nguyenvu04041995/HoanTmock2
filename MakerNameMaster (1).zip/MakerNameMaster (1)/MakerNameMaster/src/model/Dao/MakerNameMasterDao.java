package model.Dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Bean.MakerNameMaster;


public class MakerNameMasterDao {

	public ArrayList<MakerNameMaster> getListMakerNameMaster() {
		ConnectData.connection = ConnectData.getconnect();
		String sql = "select * from MakerNameMaster";
		ResultSet rs = null;
		Statement stmt = null;
	
			try {
				stmt = ConnectData.connection.createStatement();
				rs = stmt.executeQuery(sql);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
	
		ArrayList<MakerNameMaster> list = new ArrayList<>();
		MakerNameMaster makerNameMaster;
		try {
			while (rs.next()) {
				makerNameMaster = new MakerNameMaster();
				makerNameMaster.setManufacturerCode(rs.getString("ManufactureCode"));
				makerNameMaster.setManufactureName(rs.getString("ManufactureName"));

				list.add(makerNameMaster);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		return list;
	}

	public void AddMakerNameMaster(String manufactureCode, String manufactureName) {
		ConnectData.connection = ConnectData.getconnect();
		String sql=	String.format("INSERT INTO MakerNameMaster(ManufactureCode,ManufactureName) "+
				" VALUES ( '%s','%s')", manufactureCode, manufactureName);
		try {
			Statement stmt = ConnectData.connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	
	

	public void UpdateMakerNameMaster(String manufactureCode, String manufactureName) throws SQLException {
		PreparedStatement prtmm = null;
		try {
			String sqlQuery = "update MakerNameMaster set ManufactureName=?"
					+ " where ManufactureCode = ?;";

			prtmm = ConnectData.connection.prepareStatement(sqlQuery);
			// set code.

			prtmm.setString(1, manufactureName);

			prtmm.setString(2, manufactureCode);

			prtmm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				prtmm.close();
			} catch (SQLException e) {
				/* ignored */
				e.printStackTrace();
				throw new SQLException();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}

	public void DeleteMakerNameMaster(String manufactureCode) throws SQLException {
		PreparedStatement prtmm = null;
		try {
			String sqlQuery = "delete FROM MakerNameMaster where ManufactureCode = ?;";
			prtmm = ConnectData.connection.prepareStatement(sqlQuery);
			prtmm.setString(1, manufactureCode);
			prtmm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				prtmm.close();
			} catch (SQLException e) {
				/* ignored */
				e.printStackTrace();
				throw new SQLException();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}

	public ArrayList<MakerNameMaster> getListTimKiem_ManufactureCode(String manufactureCode) throws SQLException {
		ConnectData.connection = ConnectData.getconnect();
		String sql;
		// kiểm tra các giá trị nhập vào rỗng thì hiển thị tất cả
		if(manufactureCode == ""){
		sql="select * from MakerNameMaster ";
		}else{
			// nếu một trong các trường khác rỗng thì sẽ hiển thị value tương
						// ứng với trường đó
			if (manufactureCode == "") {
				manufactureCode = null;
			}
			sql="select * from MakerNameMaster where ManufactureCode like N'%"+ manufactureCode + "%'";
		}
		ResultSet rs = null;
		try {
			PreparedStatement stmt=ConnectData.connection.prepareStatement(sql);

			rs=stmt.executeQuery();

		} catch (SQLException e) {
			throw new SQLException("Error occur: " + e.getMessage());
		}
		ArrayList<MakerNameMaster>list= new ArrayList<MakerNameMaster>();
		MakerNameMaster makerNameMaster;
		try {
			while(rs.next()){
				makerNameMaster = new MakerNameMaster();
				makerNameMaster.setManufacturerCode(rs.getString("ManufactureCode"));
				makerNameMaster.setManufactureName(rs.getString("ManufactureName"));
				list.add(makerNameMaster);
				
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return list;
	}

}
