package model.Bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.Bean.MakerNameMaster;
import model.Dao.MakerNameMasterDao;



public class MakerNameMasterBo {
	MakerNameMasterDao makerNameMasterDao=new MakerNameMasterDao();
  
	public ArrayList<MakerNameMaster>getListMakerNameMaster(){
		return makerNameMasterDao.getListMakerNameMaster();
		
	}
	public void AddMakerNameMaster(String manufactureCode, String manufactureName) {
		makerNameMasterDao.AddMakerNameMaster(manufactureCode, manufactureName);
	}
	public ArrayList<MakerNameMaster>getListTimKiem_ManufactureCode(String manufactureCode) throws SQLException{
		return makerNameMasterDao.getListTimKiem_ManufactureCode(manufactureCode);
		
	}
	public void UpdateMakerNameMaster(String manufactureCode,String manufactureName) throws SQLException {

		makerNameMasterDao.UpdateMakerNameMaster(manufactureCode,manufactureName);
	}
	public void DeleteMakerNameMaster(String manufactureCode) throws SQLException {
		// TODO Auto-generated method stub
		makerNameMasterDao.DeleteMakerNameMaster(manufactureCode);
	}
}
