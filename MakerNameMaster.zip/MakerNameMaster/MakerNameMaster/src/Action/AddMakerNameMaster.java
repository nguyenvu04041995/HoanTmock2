package Action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import Form.MakerNameMasterForm;
import Common.StringProcess;
import model.Bo.MakerNameMasterBo;

public class AddMakerNameMaster extends Action {
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		MakerNameMasterForm makerNameMasterForm = (MakerNameMasterForm) form;
		MakerNameMasterBo makerNameMasterBo = new MakerNameMasterBo();
		ActionErrors actionErrors = new ActionErrors();
		if ("更新(U)".equals(makerNameMasterForm.getSubmit())) { 
			if (!StringProcess.isValidNameMasterForm(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError1", new ActionMessage("error.msv1.regionnametrong"));
			}
			if (StringProcess.maxlengthNameMasterForm(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError2", new ActionMessage("error.msv2.khongqua2kt"));
			}
			if (StringProcess.getValidSpaceFirstLastString(makerNameMasterForm.getManufactureCode())) {
				actionErrors.add("msvError51", new ActionMessage("error.msv51.daucach"));
			}
			
			saveErrors(request, actionErrors);
			if (actionErrors.size() > 0) {
				return mapping.findForward("AddMakerNameMaster");
			}
			if (actionErrors.isEmpty()) {
				String[] manufactureCode = makerNameMasterForm.getManufactureCode();
				String[] manufactureName = makerNameMasterForm.getManufactureName();
	            
				for (int i = 0; i < 10; i++) {
					
				makerNameMasterBo.AddMakerNameMaster(manufactureCode[i], manufactureName[i]);
				}
				return mapping.findForward("AddMakerNameMasterxong");
			}
		} else {
			String[] manufactureCode = {"","","","","","","","","",""};
			String[] manufactureName = {"","","","","","","","","",""};
			makerNameMasterForm.setManufactureCode(manufactureCode);
			makerNameMasterForm.setManufactureName(manufactureName);
		}
	
		return mapping.findForward("AddMakerNameMaster");
	}
}
