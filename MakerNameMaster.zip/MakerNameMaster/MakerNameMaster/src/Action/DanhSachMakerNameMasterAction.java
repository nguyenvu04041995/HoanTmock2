package Action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


import Common.StringProcess;
import Form.DanhSachMakerNameMasterForm;

import model.Bean.MakerNameMaster;
import model.Bo.MakerNameMasterBo;

public class DanhSachMakerNameMasterAction extends Action {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.
	 * ActionMapping, org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		DanhSachMakerNameMasterForm danhSachMakerNameMasterForm = (DanhSachMakerNameMasterForm) form;
		MakerNameMasterBo makerNameMasterBo = new MakerNameMasterBo();
		String manufactureCode = danhSachMakerNameMasterForm.getManufactureCode();
		
		ArrayList<String> focus = new ArrayList<String>();

		if (danhSachMakerNameMasterForm.getSubmitUpdate() != null) {
			String[] updateChar = danhSachMakerNameMasterForm.getUpdateChar();
			String[] manufactureCode1 = danhSachMakerNameMasterForm.getManufactureCode1();
			String[] manufactureName = danhSachMakerNameMasterForm.getManufactureName();

			// Variable check error item 26.
			int checkLoiItem26 = 0;
			int checkLoiItem36 = 0;
			int checkSchoolLoi = 0;

			for (int i = 0; i < updateChar.length; i++) {
				if (!updateChar[i].equals("")) {

					// Failure condition input item 26 C D
					if (StringProcess.isItem26(updateChar[i]) == true) {

						// if item 26 is C then continue valid
						if (updateChar[i].equals("c") || updateChar[i].equals("C")) {
							if (checkSchoolLoi == 0 && checkLoiItem36 == 0) {
								// When check success then perform method
								makerNameMasterBo.UpdateMakerNameMaster(manufactureCode1[i], manufactureName[i]);
							}

						} else if (updateChar[i].equals("d") || updateChar[i].equals("D")) {
							makerNameMasterBo.DeleteMakerNameMaster(manufactureCode1[i]);
						}
					} else {
						checkLoiItem26++;
						focus.add("test1234" + String.valueOf(i + 1));

					}
				}
			}

		}

		ArrayList<MakerNameMaster> listAfterUpdate = makerNameMasterBo.getListMakerNameMaster();
		if (manufactureCode == null) {
			listAfterUpdate = makerNameMasterBo.getListMakerNameMaster();
		} else {
			listAfterUpdate = makerNameMasterBo.getListTimKiem_ManufactureCode(manufactureCode);

		}
		danhSachMakerNameMasterForm.setListMakerNameMaster(listAfterUpdate);

		return mapping.findForward("dsMakerNameMaster");

	}
	

}
