package Common;


/**
 * ListAutCarnmAction.java
 *
 * Version 1.0
 *
 * Date: May 18, 2017
 *
 * Copyright HueTT8
 *
 * Modification Logs: DATE AUTHOR DESCRIPTION
 * ----------------------------------------------------------------------- May
 * 18, 2017  Create
 * 
 */

public class StringProcess {

	/**
	 * Check value input C D ?.
	 * 
	 * @param s
	 * @return
	 */
	public static boolean isItem26(String s) {
		String regex1 = "c";
		String regex2 = "C";
		String regex3 = "d";
		String regex4 = "D";
		if (s.matches(regex1) || s.matches(regex2) || s.matches(regex3) || s.matches(regex4)) {
			return true;
		} else {
			return false;
		}
	}

	public static boolean isValidNameMasterForm(String[] manufactureCode) {
	for (String factureCode : manufactureCode) {
			if (factureCode.trim().length() != 0) {
				return true;
			}
		}
	return false;
		
		
	}

	public static boolean maxlengthNameMasterForm(String[] manufactureCode) {
		for (String factureCode : manufactureCode) {
			if (factureCode.length() > 2) {
				return true;
			}
		}
		return false;
	}

	public static boolean getValidSpaceFirstLastString(String[] manufactureCode) {
		for (String factureCode : manufactureCode) {
			String s1 = factureCode.trim();
			String s2 = factureCode.replaceAll("  ", " ");
			if ((factureCode.length() > s1.length()) && (factureCode.length() > s2.length())) {
				return true;

			}
		}
		return false;
	}
}
