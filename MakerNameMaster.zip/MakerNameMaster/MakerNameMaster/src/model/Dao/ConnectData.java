package model.Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * ConnectData.java
 *
 * Date: May ‎8, ‎2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May ‎8, ‎2017        	VuNQ2         Create
 */
/**
 * Class ket noi DB
 *
 */
public class ConnectData {
	static String url = "jdbc:sqlserver://localhost:1433;databaseName=DBMakerNameMaster";
	static String userName = "sa";
	static String password = "12345678";
	public static Connection connection;

	public static Connection getconnect() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			try {
				connection = DriverManager.getConnection(url, userName, password);
				System.out.println("Ket noi thanh cong");
			} catch (SQLException e) {

				System.out.println("Ket noi that bai");
			}

		} catch (ClassNotFoundException e) {

			System.out.println("ket noi that bai");
		}

		return connection;

	}
}