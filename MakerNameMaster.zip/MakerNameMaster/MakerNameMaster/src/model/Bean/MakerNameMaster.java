package model.Bean;

public class MakerNameMaster {
	
	private String manufactureCode;
	private String manufactureName;
	private String updateChar;

	private String manufacturerCode1;
	
	
	
	/**
	 * @return the manufactureCode1
	 */
	
	/**
	 * @return the manufacturerCode
	 */
	public String getManufacturerCode() {
		return manufactureCode;
	}
	/**
	 * @param manufacturerCode the manufacturerCode to set
	 */
	public void setManufacturerCode(String manufacturerCode) {
		this.manufactureCode = manufacturerCode;
	}
	/**
	 * @return the manufactureName
	 */
	public String getManufactureName() {
		return manufactureName;
	}
	/**
	 * @param manufactureName the manufactureName to set
	 */
	public void setManufactureName(String manufactureName) {
		this.manufactureName = manufactureName;
	}
	/**
	 * @param manufactureCode
	 * @param manufactureName
	 */
	/**
	 * @return the manufactureCode
	 */
	public String getManufactureCode() {
		return manufactureCode;
	}
	/**
	 * @param manufactureCode the manufactureCode to set
	 */
	public void setManufactureCode(String manufactureCode) {
		this.manufactureCode = manufactureCode;
	}
	/**
	 * @return the updateChar
	 */
	public String getUpdateChar() {
		return updateChar;
	}
	/**
	 * @param updateChar the updateChar to set
	 */
	public void setUpdateChar(String updateChar) {
		this.updateChar = updateChar;
	}
	/**
	 * @param manufactureCode
	 * @param manufactureName
	 * @param updateChar
	 */
	public MakerNameMaster(String manufactureCode, String manufactureName, String updateChar) {
		super();
		this.manufactureCode = manufactureCode;
		this.manufactureName = manufactureName;
		this.updateChar = updateChar;
	}
	/**
	 * 
	 */
	public MakerNameMaster() {
		super();
	}
	/**
	 * @return the manufacturerCode1
	 */
	public String getManufacturerCode1() {
		return manufacturerCode1;
	}
	/**
	 * @param manufacturerCode1 the manufacturerCode1 to set
	 */
	public void setManufacturerCode1(String manufacturerCode1) {
		this.manufacturerCode1 = manufacturerCode1;
	}
	

	
	
	
	
	
	
	

}
